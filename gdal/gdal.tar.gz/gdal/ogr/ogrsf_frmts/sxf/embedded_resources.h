// SPDX-License-Identifier: MIT
// Copyright 2024, Even Rouault <even.rouault at spatialys.com>

#include "cpl_port.h"

CPL_C_START

const unsigned char *SXFGetDefaultRSC(int *pnSize);

CPL_C_END
